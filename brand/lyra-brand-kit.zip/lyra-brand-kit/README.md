# Lyra brand and launch kit

This folder holds Lyra's identity and launch material: the app icon, the logo, colour and type rules, an ad campaign, and the sources that render them. The landing page lives in [`../site`](../site). Every asset is rendered from source, so a change to a colour or a star position only needs one rebuild (see [Rebuilding](#rebuilding)).

## The brief

Lyra is a small, quiet browser for short web errands: look one thing up, check a dev server, read a doc page, close it again. The app already has a clear design language: one 44px row, ink on white paper, one amber highlighter colour that only ever means "here", clusters of tabs on tethers, a toy of bright balls on the new tab page, and Atkinson Hyperlegible Next. This kit turns that language into a brand, then uses it to sell and install the browser.

The reference is Apple's product marketing: confident type, a lot of air, the product as the hero, one idea per frame. The palette and the shapes come from Lyra, not from Apple.

**Audience.** People who already have a main browser full of tabs and want a light second one: developers, students, anyone who likes tools that stay out of the way. They notice details, so every claim has to be true and visible in the app.

**Job.** In five seconds, a visitor understands "the light browser for short errands". In thirty, they believe the details. Then they download it.

## The idea: a little cluster

Lyra keeps tabs the way you keep errands: in small clusters, each one a window of its own. On the clusters plane a cluster is a dark master ball with its tabs hanging off it, and the new tab page has a toy of bright, squishy balls.

So the mark is a cluster of those balls: **four orbs, packed close, glowing softly on the ink sky of the night sections.** The orbs bring the colour, and it stays soft. Amber keeps its one job in the row: it always means "here".

| | |
|---|---|
| Tagline | **Browse lightly.** |
| Product truths | **One row. One colour in it. Tabs in clusters.** |
| Campaign | **You are here.** |

## Identity system

### Symbol: the cluster

Four of the new tab's balls: coral (the master, like the plane's dark master ball), sky, sage and lavender. They're laid out by the same rule the clusters plane uses: each orb sits a hairline from the ones it touches. Each orb is lit from above, with a soft highlight, and on night a bloom of its own colour. There are no tethers, so the mark never reads as the cluster button in the row.

### Wordmark

"Lyra" in Atkinson Hyperlegible Next SemiBold (600), tracked -0.035em, over the highlighter stroke, exactly as the new tab page already draws it. It's outlined to SVG paths so it renders anywhere without the font.

### App icon

There are three appearances, like Apple's light, dark and tinted icons:

- **Night** (default) is the ink squircle sky with the cluster glowing in its own colours.
- **Paper** is a paper squircle with the orbs resting on it, each with a soft shadow.
- **Tinted** is the cluster in greys, for monochrome contexts.

Sizes from 16 to 48px are redrawn, not just scaled down. The gaps widen to about a device pixel so the orbs never run together, and the bloom goes.

The app's 16px glyph (`#i-lyra`, in the address field on a new tab and on the plane) is the same cluster drawn as stroke rings.

### Colour

| Role | Name | Value |
|---|---|---|
| Core | Paper | `#FFFFFF` |
| Core | Ink | `#191B1F` |
| Core | Mark | `#E8A33D` |
| Neutral | Surface | `#F2F3F5` |
| Neutral | Surface deep | `#E8EAEE` |
| Neutral | Rule | `#E3E5E9` |
| Neutral | Graphite | `#6E737B` |
| Neutral | Graphite soft | `#9BA0A8` |
| Night (marketing) | Night top / Night / Night deep | `#2B2E35` / `#191B1F` / `#111215` |
| Night (marketing) | Starlight / Mark glow | `#F4F5F7` (at 92%, 60% or 30%) / `#FFD08A` |
| Orbs (secondary) | Coral, Sky, Sage, Lavender, Butter | `#E47C6A` `#7FA9DF` `#8CBF9C` `#B49FE0` `#F0CF8E` |

The rules follow the app's. The mark is never text and never a background fill. It shows up once per composition, as a stroke, a ring or a glow, and it means "here". Amber on paper is only 2.2:1, so it never carries meaning on its own.

The orbs are the new tab balls and the icon's colours, and they're secondary in the same quiet way as the mark: soft light behind the product, an out-of-focus glow on night, the balls themselves, and favicons in product shots. They're never text and never a large flat fill. Butter sits too close to the mark, so the icon leaves it out.

### Type

Atkinson Hyperlegible Next is the only typeface. It was drawn by the Braille Institute so that similar characters never pass for each other. In an address bar that's a security property, and it makes a strong story for marketing too.

| Use | Setting |
|---|---|
| Display | 700, tracking -0.045em, line height 1.0 |
| Headline | 650, tracking -0.03em, line height 1.08 |
| Body | 400, 17 to 19px, line height 1.5 |
| Caption | 400, 13 to 14px, Graphite |

Use sentence case everywhere. No all caps, no letter-spaced eyebrows, no monospace.

### Graphic devices

1. **The highlighter stroke** sits under the one thing that is "here", once per surface.
2. **Tethers** are thin graphite lines ending in small discs. They replace arrows in callouts and diagrams.
3. **The plane's grid** is the clusters plane's dot grid, used behind diagrams.
4. **The orb glow** is the icon's cluster out of focus: four soft lights in the orb colours, used on night backgrounds.

### Voice

Sentence case, plain verbs, from the reader's side, and true. Headlines are short declaratives with full stops. The tone is dry rather than cute. Every claim is something the app actually does.

## Campaign: "You are here."

| Execution | Headline | Formats |
|---|---|---|
| Hero | Browse lightly. | 1080×1080, 1080×1350, 1920×1080, 1200×630 |
| Mark | You are here. | 1080×1080, 1080×1920 |
| Row | One row. | 1080×1350, 1500×500 |
| Type | Tell rn from m. | 1080×1080 |
| Clusters | Your tabs, in clusters. | 1080×1350, 1080×1920 |
| Key | One key does the finding. | 1080×1080 |
| Errand | Forty tabs over there. One errand here. | 1080×1080 |
| Billboard | Browse lightly. | 2400×1200 |

## Landing page

An Apple-style product page: one idea per section, massive tight headlines, small muted copy, and a lot of air. Sections alternate paper and night at full width. Motion is a short fade and rise as each section arrives, the laptop growing into view, and one sticky section that tells how clusters work as you scroll. All of it holds still for reduced motion. The orb colours appear only as light: a soft glow behind the laptop, the new tab's balls inside it, the favicons, and an out-of-focus cluster on night.

```
┌ nav (frosted, dark over night) ─ Lyra ──────────────────── Clusters  Type  [Download] ┐
│ paper   Browse lightly.  (massive)                                                     │
│         The small, quiet browser for everything that takes five minutes.               │
│         [ Download for Windows ]                                                       │
│         ┌ laptop: the new tab page with the balls out, orb light behind ┐              │
│ night   44px · 1 (with the one amber point) · 0 · 34 KB   big numbers, tiny captions   │
│ paper   Tabs, in clusters.  sticky: the floor → two clusters → the other window        │
│ night   Tell rn from m.  the type specimen, huge, the orb glow far off                 │
└ footer ─ Brand guidelines, Releases ───────────────────────────────────────────────────┘
```

## Review against the brief: what changed and why

- **The hero was going to be a starry night sky.** That's the stock "near-black with one bright accent" look, and it contradicts a product that's white paper. Now the page is paper, and night only appears where the product shows it.
- **Features were going to be a grid of matching rounded cards.** Now features are shown as crops of the real UI with tethered callouts, and the small details are a plain list using the app's own icons.
- **Amber was going to make the buttons pop.** Now buttons are ink, and amber stays a stroke, ring or glow that means "here", as it does in the app.
- **The hero was going to lead with the wordmark.** Now it leads with the promise and the product window, and the wordmark appears where the app shows it: on the new tab page inside that window.

Second round, after the owner's Apple-style direction ("less is more"):

- **Nine sections became eight**, each with a single idea and about a third of the copy. The colour and shortcut sections folded into the bento grid.
- **The numbers strip risked being template.** The "1 colour" figure carries the actual amber point, so the only colour on the strip is in the stat about the only colour.
- **Identical white tiles** became a grid with one night tile, and the colour tile shows only the field and its stroke.
- **The product sat below the fold.** The hero tightened so the laptop shows on the first screen.

Third round, after the owner's direction to centre the brand on clusters:

- **The constellation became a cluster of orbs.** The icon, symbol, lockups, favicons, installer icon and the app's 16px glyph are now four of the new tab's balls, packed the way the plane packs clusters.
- **The new tab balls became the secondary colours**, used as softly as the mark: light, glow, favicons.
- **The sticky story now explains clusters**, from loose tabs on the floor to a cluster's own window. The address-bar story, the finder, the bento grid and the closing section are gone, so the page has four sections.

## Contents

| Path | What |
|---|---|
| `icon/` | App icon masters (SVG, in full-bleed, macOS and Windows frames), every PNG size, `lyra.ico`, `lyra.icns` |
| `logo/` | Lockups, wordmark (with and without the stroke), symbol and the 16px glyph, as SVG and PNG |
| `color/` | Palette sheet, `tokens.css`, `tokens.json`, `lyra.ase` (Adobe), `lyra.gpl` (GIMP, Inkscape) |
| `ads/` | The campaign: 10 executions, 16 renders, from 400x400 to 2400x1200 |
| `src/` | The generators and templates everything is rendered from |
| `../site/` | The landing page and the brand guide (`site/brand/`), built from `src/site/` |
| `../build/` | Installer icons, written by the icon build |

The icon build also writes the app's window icon to `src/shared/icons/`, and the 16px glyph lives in the chrome's sprite (`src/renderer/index.html`, `#i-lyra`) and on the clusters plane.

## Rebuilding

Render everything (icons, logos, colour files, the campaign, the site) with headless Microsoft Edge:

```powershell
npm run brand
```

Or just one part, for example after changing a headline:

```powershell
npm run brand -- ads site
```

Once the site has an address, the ads can carry it:

```powershell
$env:LYRA_SITE_URL = 'andrewchampagne.github.io/lyra'; npm run brand -- ads site
```

## Shipping

Build the installer, a one-click NSIS setup that installs for the current user:

```powershell
npm run dist
```

Publish the site to GitHub Pages and the installer to GitHub Releases, in a public repository that holds only those two things. It needs the GitHub CLI, signed in:

```powershell
npm run publish-site
```

The landing page is edited in `brand/src/site/index.html` (copy and structure) and `site/assets/site.css` and `site.js` (style and behaviour). The product shots on the page are injected from the UI kit in `src/lib/ui.mjs`, so they match the ads.

Every stylesheet and script link carries a content hash (`site.css?v=84d1b503`), so a browser can never pair a new page with an old stylesheet. After editing `site.css` or `site.js`, run `npm run brand -- site` to refresh the hashes. To preview, run `node brand/src/serve.mjs`, which serves `site/` on http://localhost:4321 with caching turned off.
